MM/GBSA Results

Each ligand directory contains the protein-ligand complex files and
corresponding MM/GBSA calculation outputs.

complex.pdb       Protein-ligand complex structure
complex.parm7     AMBER topology/parameter file
complex.rst7      AMBER coordinate/restart file
mmgbsa.dat        Raw MM/GBSA output
decomposition.dat Per-residue energy decomposition output

The computational parameters and MM/GBSA protocol are described in
the Methods section of the manuscript.